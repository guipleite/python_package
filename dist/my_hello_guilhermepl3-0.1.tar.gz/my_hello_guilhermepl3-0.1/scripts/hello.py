#!/usr/bin/env python3

import my_hello

my_hello.world()